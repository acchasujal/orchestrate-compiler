"""Message notification router package."""
