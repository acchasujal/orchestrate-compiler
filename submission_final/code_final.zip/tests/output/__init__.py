"""Justification and output tests."""
