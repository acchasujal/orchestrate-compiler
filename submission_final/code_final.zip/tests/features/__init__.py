"""Feature extraction tests."""
