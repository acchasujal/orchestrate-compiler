"""Resolver tests."""
