"""Application tests."""
